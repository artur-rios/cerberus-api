## Task 1: Strict encoding with reproducible test runners

**Files:** Create `J/ProtocolJson.java`, `J/ProtocolError.java`, `P/encoding.py`, `P/errors.py`, `P/__init__.py`, `PT/__init__.py`, `JT/Fixtures.java`, `PT/fixtures.py`, `tools/protocol-harness/java/pom.xml`, `java/mvnw`, `java/.mvn/wrapper/maven-wrapper.properties` under the harness, `tools/protocol-harness/dependencies.lock.json`, `tools/protocol-harness/python/requirements.lock`, `tools/protocol-harness/README.md`, `tools/protocol-harness/.gitignore`. Test `JT/EncodingTest.java`, `PT/test_encoding.py`.

**Interfaces:** Produces `ProtocolJson.context(List<Object>) -> byte[]`, `parse(byte[], Set<String> required, Set<String> optional, int maxBytes) -> Map<String,Object>`, `base64(byte[]) -> String`, `unbase64(String,int expectedLength) -> byte[]`, `guid(String) -> String`, `integer(Object,long min,long max) -> long`; Python `context`, `parse`, `base64`, `unbase64`, `guid`, `integer` with equivalent types. `ProtocolError.code` is `invalid_protocol` or `unsupported_dependency`. Contract validators call `parse` on raw inputs then recursively enforce their own exact nested schemas; generic parsing itself rejects duplicates and nonintegral number tokens recursively.

- [ ] Write `GivenCanonicalArray_WhenEncoded_ThenBytesMatch` and rejection tests in both suites:

```python
self.assertEqual(context(["cerberus-v1", 1, [], True, None]),
                 b'["cerberus-v1",1,[],true,null]')
for value in (True, 0, 9007199254740992, "1", 1.0):
    with self.assertRaises(ProtocolError): integer(value, 1, 9007199254740991)
for raw in (b'{"x":1,"x":2}', b'{"x":1e0}', b'{"x":1.0}', b'\xef\xbb\xbf{"x":1}'):
    with self.assertRaises(ProtocolError): parse(raw, {"x"}, set(), 1048576)
```

Include unknown/nested duplicate fields, invalid UTF-8/surrogates, non-ASCII
context strings, trailing JSON, reordered properties accepted, empty/uppercase/
zero GUIDs, base64 padding/alphabet/unused bits/decoded lengths, and total request
limit at/over boundary including many individually small fields (Review Focus 1).

- [ ] Bootstrap only the test runners and run RED: `tools/protocol-harness/java/mvnw -f tools/protocol-harness/java/pom.xml -Dtest=EncodingTest test`; `PYTHONPATH=tools/protocol-harness/python python -m unittest tests.test_encoding -v`. Expected missing `ProtocolJson`/`encoding`, not a network, discovery or missing-runner failure.
- [ ] Implement the listed encoding APIs using Jackson streaming strict duplicate detection and Python raw numeric-token hooks; reject nonintegral lexical forms before conversion. Bound UTF-8 bytes before parsing. Use separate constrained array writers and independent schema checks.
- [ ] Pin the declared dependencies, all resolved transitives and explicit Maven plugin versions; forbid ranges/snapshots. Pin Maven 3.10.0 wrapper distribution SHA-256 from the authenticated upstream artifact and Python wheel hashes. Record JDK/Python patch versions and graph/artifact hashes in `dependencies.lock.json`; use `/tmp` for local caches/venv. Document exact setup commands and ignore only harness build/cache outputs.
- [ ] Run both RED commands again: expected nonzero tests discovered, zero failures/errors/skips. Record counts and runner reports; do not equate an empty suite with success.
- [ ] Commit only this task's files: `git commit -m "feat: add strict harness encoding"` after explicit `git add` of the Files paths, not repository-wide staging.

