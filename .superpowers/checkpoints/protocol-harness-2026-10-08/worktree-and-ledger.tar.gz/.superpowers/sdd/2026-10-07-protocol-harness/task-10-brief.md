## Task 10: Isolated password-derivation measurements

**Files:** Create `tools/protocol-harness/benchmark.py`, `tools/protocol-harness/tests/test_benchmark.py`, `docs/security/protocol-harness-benchmarks.json`; extend `J/Main.java`, `P/__main__.py` with benchmark child command. Modify `tools/protocol-harness/README.md`.

**Interfaces:** Consumes `Primitives.argon2(byte[],byte[]) -> byte[]`, Python `argon2(bytes,bytes) -> bytes`, and Task 9 CLIs. Both CLIs support `benchmark <samples> <results-file>` using fixed public password/salt/profile, one warm-up and default 10 measured derivations, no derived key output. `benchmark.run(java_command:list[str],python_command:list[str],samples:int,output:Path) -> dict` runs each implementation in its own fresh process.

- [ ] Write `GivenBenchmarkChildFailure_WhenMeasured_ThenNoSuccessArtifact`:

```python
with self.assertRaises(HarnessFailure): run(java_fails, python_ok, 10, target)
self.assertEqual(target.read_bytes(), previous_valid_bytes)
self.assertEqual(success["java"]["profile"]["memoryKiB"], 65536)
self.assertEqual(success["python"]["samples"], 10)
self.assertTrue(all(t > 0 for t in success["python"]["elapsedMilliseconds"]))
```

Test zero/negative samples, missing runtime, duplicate/short samples, bogus RSS/
units, missing environment/library versions and secret marker redaction (Focus 5).

- [ ] Run RED: `python3 -m unittest discover -s tools/protocol-harness/tests -p 'test_benchmark.py' -v`. Expected absent benchmark behavior, not fabricated metric assertions.
- [ ] Implement isolated child measurements with warm-up, monotonic elapsed samples, min/median/p95/max and OS/CPU architecture/runtime/library/profile metadata. On Linux use process peak RSS measured by the orchestrator via wait4, report bytes and exact measurement method; it includes runtime/JIT baseline, not isolated Argon2 allocation. An unsupported platform fails with a stated measurement limitation, never invents RSS. No latency SLO or mobile compatibility claim.
- [ ] Run the RED command GREEN, both native suites, and `python tools/protocol-harness/benchmark.py --samples 10 --output docs/security/protocol-harness-benchmarks.json`; review actual measurements and classification.
- [ ] Stage the exact Files paths and commit: `git commit -m "test: measure isolated password derivation"`.

