## Task 2: Qualified primitives, keys and authoritative known answers

**Files:** Create `J/Primitives.java`, `J/Keys.java`, `P/primitives.py`, `P/keys.py`, `tools/protocol-harness/fixtures/input.json`, `tools/protocol-harness/fixtures/known-answers.json`, `tools/protocol-harness/fixtures/sources.json`, `tools/protocol-harness/audit.py`, `tools/protocol-harness/tests/test_audit.py`; extend test support and locks. Test `JT/PrimitivesTest.java`, `JT/KeysTest.java`, `PT/test_primitives.py`, `PT/test_keys.py`.

**Interfaces:** Consumes Task 1 `ProtocolJson.context(List<Object>) -> byte[]`, `base64(byte[]) -> String`, `unbase64(String,int) -> byte[]`. Produces `Primitives.hkdf(byte[] root,byte[] salt,byte[] info,int length) -> byte[]`, `argon2(byte[] password,byte[] salt) -> byte[]`, `gcmSeal(byte[] key,byte[] nonce,byte[] aad,byte[] plaintext) -> byte[]` (ciphertext+tag), `gcmOpen(byte[] key,byte[] nonce,byte[] aad,byte[] ciphertextAndTag) -> byte[]`, `sha256(byte[]) -> byte[]`; Python same snake_case. `Keys.generate() -> byte[]` PKCS#8, `publicJwk(byte[] privateDer) -> Map`, `thumbprint(Map jwk) -> String`, `sign(byte[] privateDer,byte[] message) -> byte[64]`, `verify(Map jwk,byte[] message,byte[] signature) -> boolean`, `validatePublic(Map jwk) -> Map`. Produce `audit(lock: Path) -> dict` in `audit.py`.

- [ ] Write `GivenRfc5869Case1_WhenDerived_ThenKnownBytesMatch`:

```python
self.assertEqual(hkdf(b'\x0b' * 22, bytes(range(13)), bytes(range(0xf0, 0xfa)), 42).hex(),
                 '3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865')
self.assertEqual(len(sign(fixture("author")["privateDer"], b"sample")), 64)
self.assertEqual(sign(fixture("author")["privateDer"], b"sample"),
                 sign(fixture("author")["privateDer"], b"sample"))
for jwk in (off_curve_jwk, infinity_encoding_jwk, wrong_curve_jwk):
    with self.assertRaises(ProtocolError): validate_public(jwk)
with self.assertRaises(ProtocolError): public_jwk(malformed_private_der)
```

Pin AES-256-GCM published NIST cases, RFC 6979 P-256/SHA-256 sample signature,
RFC 7638 example thumbprint, RFC 9106 Argon2id published vector (primitive-only
test may use that vector's parameters/secret/AD; protocol API cannot), and RFC
9180 P-256/HKDF-SHA-256/AES-256-GCM base-mode cases. Preserve upstream revision,
file hash, URL and license in sources, never use self-generated expected outputs
as known answers. Add `GivenInvalidKeyMaterial_WhenImported_ThenRedactedRejection`
for off-curve/infinity, wrong curves, malformed/trailing DER, zero/out-of-range
signature scalars and incorrect lengths (Review Focus 2). Audit tests simulate
vulnerabilities, empty/malformed/missing responses, network failure and lock drift.

- [ ] Run RED: `tools/protocol-harness/java/mvnw -f tools/protocol-harness/java/pom.xml -Dtest=PrimitivesTest,KeysTest test`; `PYTHONPATH=tools/protocol-harness/python python -m unittest tests.test_primitives tests.test_keys -v`; `python3 -m unittest discover -s tools/protocol-harness/tests -p 'test_audit.py' -v`. Expected missing primitive/key/audit APIs.
- [ ] Implement the listed APIs using Bouncy Castle generators/GCM/ECDsaSigner with HMacDSAKCalculator(SHA256Digest), and cryptography Argon2id/HKDF/AESGCM/ECDSA with deterministic signing. Parse DER/curve points through libraries; never implement scalar arithmetic. Return no plaintext until tag validation succeeds. Verify actual selected library support with a smoke test; unavailable deterministic signing/Argon2/HPKE blocks adoption.
- [ ] Add native-library HPKE known-answer open/seal checks, with fixture-only supplied ephemeral material if the API permits; otherwise verify published decrypt vectors and separate randomized cross-seal later. Create distinct role-key fixture pairs through library APIs, never derive them from recovery secret/password. Record them only in the public fixture corpus.
- [ ] Implement audit using the official OSV version-query API for every resolved Maven/PyPI package plus build/test dependencies; compare installed/resolved graph and hashes to lock first. A finding, response-count mismatch, unresolved dependency or feed outage exits nonzero. Send only public package coordinates/versions, never fixture/secret input. Record scan date, feed and limitations; no scan implies proof of library correctness.
- [ ] Run all RED commands GREEN and `python3 tools/protocol-harness/audit.py`; require complete tests, valid published expected values and a successful current audit before proceeding.
- [ ] Stage the exact Files paths and commit: `git commit -m "feat: qualify harness crypto primitives"`.

