## Task 3: Context-bound symmetric envelopes and consumed salt guard

**Files:** Create `J/Context.java`, `J/Symmetric.java`, `J/NonceGuard.java`, `P/symmetric.py`. Test `JT/SymmetricTest.java`, `PT/test_symmetric.py`.

**Interfaces:** Consumes `ProtocolJson.context(List<Object>) -> byte[]`, `Primitives.hkdf(byte[],byte[],byte[],int) -> byte[]`, `gcmSeal(byte[],byte[],byte[],byte[]) -> byte[]`, `gcmOpen(byte[],byte[],byte[],byte[]) -> byte[]`. Produces `Context(ownerId:String,resourceKind:String,resourceId:String,keyEpoch:long,extraContext:List<Object>)`; equivalent Python dataclass. `Symmetric.seal(byte[] root,Context expected,String format,byte[] plaintext,NonceGuard guard) -> Map`, `sealFixture(byte[] root,Context expected,String format,byte[] plaintext,NonceGuard guard,byte[] salt,byte[] nonce) -> Map` (explicit test API), `open(byte[] root,Context expected,String format,Map envelope) -> byte[]`; Python names are `seal`, `seal_fixture`, `open_envelope`. `NonceGuard.reserve(byte[] root,Context expected,byte[] salt) -> void` and constructor `NonceGuard(long initialCount)`; Python equivalent. Guard indexes a nonlogged fingerprint of root+context+salt, not a caller-supplied mutable identity.

- [ ] Write `GivenUsedSaltContext_WhenSealedAgain_ThenRejected`:

```python
env = seal_fixture(root, ctx, "cerberus-content-v1", b"public fixture", guard, salt, nonce)
self.assertEqual(open_envelope(root, ctx, "cerberus-content-v1", env), b"public fixture")
with self.assertRaises(ProtocolError):
    seal_fixture(root, ctx, "cerberus-content-v1", b"edit", guard, salt, b'\x02' * 12)
self.assertEqual(env["keyEpoch"], 1)
self.assertEqual(len(unbase64(env["tag"], 16)), 16)
```

Cover all five content kinds; changed owner/resource/epoch/format/purpose/salt/
nonce/ciphertext/tag; empty plaintext/ciphertext; input bounds; no partial output;
normal API uses fresh secure salt+nonce; failed encryption consumes reservation;
lost-response retry reuses saved bytes; budget allows final permitted reservation
but rejects the next at `2^32`; changed root/epoch starts a distinct modeled budget.

- [ ] Run RED: `tools/protocol-harness/java/mvnw -f tools/protocol-harness/java/pom.xml -Dtest=SymmetricTest test`; `PYTHONPATH=tools/protocol-harness/python python -m unittest tests.test_symmetric -v`. Expected missing Context/Symmetric.
- [ ] Implement those signatures and exact spec §5.1 info/AAD arrays. Guard reservation is atomic and occurs before encryption; fixed material accepted only by `sealFixture`/`seal_fixture`. Enforce expected epoch and strict envelope fields at open; allow format extensions only inside the following named wrapper APIs.
- [ ] Run both commands GREEN; all mutations reject and saved retries are byte-identical.
- [ ] Stage the Files paths and commit: `git commit -m "feat: add context-bound vault envelopes"`.

