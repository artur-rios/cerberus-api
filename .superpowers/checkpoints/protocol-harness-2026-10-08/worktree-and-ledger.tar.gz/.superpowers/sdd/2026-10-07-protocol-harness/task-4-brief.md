## Task 4: Scoped password and recovery protection bundles

**Files:** Create `J/Protection.java`, `J/RecoveryBundle.java`, `P/protection.py`, `P/recovery_bundle.py`; extend data-only inputs and builders. Test `JT/ProtectionTest.java`, `PT/test_protection.py`.

**Interfaces:** Consumes `Symmetric.seal(byte[],Context,String,byte[],NonceGuard) -> Map`, `open(byte[],Context,String,Map) -> byte[]`, `Keys.publicJwk(byte[]) -> Map`, `Primitives.argon2(byte[],byte[]) -> byte[]`. Produces `Protection.validate(Map bundle,String scopeKind,String scopeId,Set<String> allowedRoots,Map unlockJwk) -> Map`, `wrap(String password,Map bundle,Context slot,NonceGuard guard) -> Map`, `unwrap(String password,Map wrapper,Context slot,Set<String> allowedRoots,Map unlockJwk) -> Map`; `RecoveryBundle.wrap(byte[] secret,Map accountBundle,byte[] proofPrivateDer,Context slot,long generation,NonceGuard guard) -> Map`, `unwrap(byte[] secret,Map wrapper,Context slot,long generation,Map recoveryJwk,Set<String> allowedRoots,Map unlockJwk) -> Map`. Allowed-root identifiers are `resourceKind + ":" + resourceId`. Python same snake_case. Each `wrapFixture`/`wrap_fixture` takes its normal wrap arguments followed by `byte[] keySalt,byte[] nonce`; password wrapping additionally takes `byte[] passwordSalt` last.

- [ ] Write `GivenProfileSlot_WhenAccountRootIncluded_ThenRejected` and `GivenChangedKdf_WhenUnwrapped_ThenNoDerivation`:

```python
with self.assertRaises(ProtocolError):
    validate(profile_with_account_root, "profile", profile_id, profile_allowed, profile_unlock_jwk)
with mock.patch("cerberus_protocol.protection.argon2") as derive:
    with self.assertRaises(ProtocolError): unwrap(password, huge_memory_wrapper, slot, allowed, unlock_jwk)
    derive.assert_not_called()
self.assertNotEqual(argon2("é".encode(), password_salt), argon2("e\u0301".encode(), password_salt))
```

Test exact UTF-8 spaces/case/composed-vs-decomposed/non-BMP and invalid surrogates;
wrong password/salt/KDF field/type/profile; huge work and aggregate bounds (Focus
1); sorted distinct roots, account/profile membership, missing/empty roots,
unrelated profile keys, unlock verifier mismatch/malformed PKCS#8 (Focus 2);
rewrap increments slot epoch but preserves permitted inner roots/content epochs;
recovery wrong secret/generation/fingerprint/scope; server public verifier cannot
decrypt; distinct per-generation proof keys and no Argon2 on raw recovery secret.

- [ ] Run RED: `tools/protocol-harness/java/mvnw -f tools/protocol-harness/java/pom.xml -Dtest=ProtectionTest test`; `PYTHONPATH=tools/protocol-harness/python python -m unittest tests.test_protection -v`. Expected missing Protection/RecoveryBundle.
- [ ] Implement the listed bundle validators and wrappers with spec §5.2/5.3 exact field sets, contexts and inner-key/public-key matching. Validate parameters and bounded wire structure before KDF; strict parse and scope checks after authenticated decrypt, before returning any usable key bundle.
- [ ] Run both commands GREEN, including an instrumented pre-KDF rejection assertion in Java; do not merely time a fast failure.
- [ ] Stage the Files paths and commit: `git commit -m "feat: add scoped protection wrappers"`.

