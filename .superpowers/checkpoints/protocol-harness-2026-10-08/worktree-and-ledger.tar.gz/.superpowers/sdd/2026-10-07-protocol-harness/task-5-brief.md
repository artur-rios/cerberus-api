## Task 5: Signed HPKE recipient envelopes and pinned client-key transitions

**Files:** Create `J/Recipient.java`, `J/ClientTrust.java`, `P/recipient.py`, `P/client_trust.py`. Test `JT/RecipientTest.java`, `PT/test_recipient.py`.

**Interfaces:** Consumes `Keys.publicJwk(byte[]) -> Map`, `thumbprint(Map) -> String`, `sign(byte[],byte[]) -> byte[64]`, `verify(Map,byte[],byte[]) -> boolean`, Task 3 `Context`, and qualified native HPKE APIs from Task 2. Produces `Recipient.wrap(byte[] resourceRoot,Context resource,String grantId,long grantRevision,String recipientIdentityId,Map recipientJwk,byte[] authorPrivateDer) -> Map`; `open(Map envelope,Context resource,String grantId,long grantRevision,String recipientIdentityId,byte[] recipientPrivateDer,ClientTrust trust) -> byte[]`. Python names are `wrap`, `open_recipient`. `ClientTrust(Map recipientJwk,Map authorJwk,long directoryRevision)` holds independently provisioned pins; `transition(String accountId,String role,Map newJwk,long revision,byte[] oldAuthorSignature) -> void`. Python equivalent.

- [ ] Write `GivenPinnedAuthorAndRecipient_WhenWrapped_ThenOnlyRecipientOpens`:

```python
env = wrap(root, ctx, grant_id, 1, recipient_id, recipient_jwk, author_private)
self.assertEqual(len(unbase64(env["enc"], 65)), 65)
self.assertEqual(len(unbase64(env["ciphertext"], 48)), 48)
self.assertEqual(open_recipient(env, ctx, grant_id, 1, recipient_id, recipient_private, trust), root)
with self.assertRaises(ProtocolError):
    open_recipient(env, ctx, grant_id, 2, recipient_id, recipient_private, trust)
```

Reject every changed info field, forged/unpinned/self-introduced author, wrong
recipient/key fingerprints/epochs, malformed points (Focus 2), corrupted enc/tag/
signature, wrong lengths and unknown fields. Spy on decapsulation to prove author
and expected binding validation precede it. Test old-author-signed transition,
new-key self-signature rejection, wrong role/account/JWK hash, nonincreasing
revision and separate recipient/author roles. Model fresh grant revision and
omission of revoked recipients without claiming erasure of old copied keys.

- [ ] Run RED: `tools/protocol-harness/java/mvnw -f tools/protocol-harness/java/pom.xml -Dtest=RecipientTest test`; `PYTHONPATH=tools/protocol-harness/python python -m unittest tests.test_recipient -v`. Expected missing Recipient/ClientTrust.
- [ ] Implement exact §6 info/signedBytes and transition arrays. Java invokes BC HPKE base seal/open with empty AAD and selected suite; Python invokes `Suite(KEM.P256,KDF.HKDF_SHA256,AEAD.AES_256_GCM)` and splits/joins its `enc || ciphertext` output at 65 bytes. Use no shared HPKE transcript code; validate APIs against the pinned release, not an assumed Java/C# parity.
- [ ] Run both commands GREEN and rerun each library's published HPKE known answers from Task 2.
- [ ] Stage the Files paths and commit: `git commit -m "feat: add signed recipient key wrapping"`.

