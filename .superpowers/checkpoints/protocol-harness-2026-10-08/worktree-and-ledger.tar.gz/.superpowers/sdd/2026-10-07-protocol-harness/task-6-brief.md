## Task 6: Exact-body challenge proofs with purpose binding

**Files:** Create `J/Challenge.java`, `P/challenge.py`. Test `JT/ChallengeTest.java`, `PT/test_challenge.py`.

**Interfaces:** Consumes `ProtocolJson.parse(byte[],Set<String>,Set<String>,int) -> Map`, `context(List<Object>) -> byte[]`, `Keys.sign(byte[],byte[]) -> byte[64]`, `verify(Map,byte[],byte[]) -> boolean`, `Primitives.sha256(byte[]) -> byte[]`. Produces `Challenge.issue(Map expectedBinding,byte[] rawBody,long now) -> Map`; `bytes(Map challenge) -> byte[]`; `sign(Map challenge,byte[] scopedPrivateDer) -> byte[]`; `verify(Map challenge,Map expectedBinding,byte[] rawBody,Map registeredJwk,byte[] signature,long now) -> void`. Expected binding contains operation, identity/account/scope IDs, key epoch, protection revision and nullable generation. Python equivalent, with secure randomness in issue; `issueFixture(Map expectedBinding,byte[] rawBody,long now,String challengeId,byte[] nonce) -> Map` is the explicit test-only fixed-material variant.

- [ ] Write `GivenBoundBody_WhenByteOrderChanges_ThenProofRejected`:

```python
challenge = issue(binding, b'{"idempotencyKey":"fixture","expectedRevision":1}', 1700000000)
self.assertEqual(challenge["expiresAt"], 1700000060)
proof = sign(challenge, scoped_private)
verify(challenge, binding, original_body, registered_jwk, proof, 1700000059)
with self.assertRaises(ProtocolError): verify(challenge, binding, original_body, registered_jwk, proof, 1700000060)
with self.assertRaises(ProtocolError): verify(challenge, binding, reordered_body, registered_jwk, proof, 1700000059)
```

Provide original/reordered bytes exactly as opposite property orders. Mutate
every proof-array field; test wrong scope/purpose/key, account scope mismatch,
generation null rules, future issue, timestamp overflow, bad length/scalars,
duplicate fields/BOM/invalid UTF-8, body at/over bound (Focus 3). Challenge request
does not create access; only registered scoped/old-generation key verifies.

- [ ] Run RED: `tools/protocol-harness/java/mvnw -f tools/protocol-harness/java/pom.xml -Dtest=ChallengeTest test`; `PYTHONPATH=tools/protocol-harness/python python -m unittest tests.test_challenge -v`. Expected missing Challenge.
- [ ] Implement exact §7 proofBytes and raw SHA-256 body binding; strict parse the same uncompressed, BOM-free bytes without reserialization. Model proposed proof headers as separate inputs, not body fields. Challenge schema is strict; only `recover` has nonnull generation as specified.
- [ ] Run both commands GREEN; confirm deterministic signature bytes against native RFC 6979 checks.
- [ ] Stage the Files paths and commit: `git commit -m "feat: add purpose-bound challenge proofs"`.

