## Task 7: Atomic local recovery, refresh and exact lost-response retry

**Files:** Create `J/RecoveryModel.java`, `P/recovery_model.py`; extend fixture builders. Test `JT/RecoveryModelTest.java`, `PT/test_recovery_model.py`.

**Interfaces:** Consumes `Challenge.verify(Map,Map,byte[],Map,byte[],long) -> void`, strict envelope schemas from Tasks 3–4 (not client plaintext unwrap), and `Keys.validatePublic(Map) -> Map`. Produces `RecoveryModel(Map initialPublicState,LongSupplier clock)` with `addChallenge(Map challenge) -> void`, `execute(String identityId,boolean freshAuth,byte[] rawBody,String challengeId,byte[] proof,boolean currentVaultAccess,boolean injectCommitFailure) -> Map nonsecretOutcome`, `snapshot() -> Map`. Python takes `Callable[[],int]` and corresponding methods. Public state contains account/scope IDs, registered public verifiers, current epoch/protection revision/recovery generation/revocation generation and opaque wrappers, never recovery secret or private key. Replacement body contains exactly operation, idempotencyKey (nonempty ASCII string bounded by the whole request), expectedRevision, passwordWrapper, recoveryWrapper, newRecoveryVerifier; expected epoch/generation derive from current state and validated replacement metadata. Outcomes contain exactly status, protectionRevision, generation, revocationGeneration; status is committed or the stored committed outcome on exact retry. Rejection throws ProtocolError; race test helpers turn that into status rejected for counting.

- [ ] Write `GivenConcurrentRecovery_WhenCommitted_ThenOneTransitionWins`:

```python
before = model.snapshot()
outcomes = run_two_synchronized_distinct_operations(model, first, second)
self.assertEqual(sum(item["status"] == "committed" for item in outcomes), 1)
self.assertEqual(model.snapshot()["protectionRevision"], before["protectionRevision"] + 1)
self.assertEqual(model.snapshot()["revocationGeneration"], before["revocationGeneration"] + 1)
self.assertEqual(exact_retry(model, first_committed_request), first_committed_outcome)
self.assertEqual(model.snapshot(), snapshot_after_first_commit)
```

Implement these test helpers per language using barriers and two threads, not
sequential calls mislabeled concurrency. Test consumed/unknown/expired challenges,
stale revision/generation, old verifier vs replacement verifier, changed identity/
body/idempotency key, no fresh auth, refresh without current vault access, refresh
invalidating old recovery, and injected failure rolling back all changes. Supply
the alternate valid ECDSA signature `(r,n-s)` using the library's P-256 order in
test support: identical operation still returns one stored result (Focus 3).
Verify the stored result contains no plaintext/secrets/private keys.

- [ ] Run RED: `tools/protocol-harness/java/mvnw -f tools/protocol-harness/java/pom.xml -Dtest=RecoveryModelTest test`; `PYTHONPATH=tools/protocol-harness/python python -m unittest tests.test_recovery_model -v`. Expected missing RecoveryModel.
- [ ] Implement a single locked atomic state transition: authenticate, check stored exact operation outcome, verify old purpose key/body, compare state, prepare complete replacements, consume challenge/generation, commit revisions/verifier/wrappers/result together. Copy tentative state so injected failure leaves no effects. Idempotency identity is authenticated identity + key + original body hash, never signature hash. Explicitly document this is not PostgreSQL or production permission verification.
- [ ] Run both commands GREEN, repeat barrier races 100 times per implementation, and require all snapshots/rollback assertions, not just winner count.
- [ ] Stage the Files paths and commit: `git commit -m "feat: model atomic recovery and retries"`.

