## Task 8: Strict offline JWS, trusted time and lease-key rotation

**Files:** Create `J/Lease.java`, `J/OfflineClock.java`, `J/LeaseTrust.java`, `P/lease.py`, `P/offline_clock.py`, `P/lease_trust.py`. Test `JT/LeaseTest.java`, `JT/OfflineClockTest.java`, `PT/test_lease.py`, `PT/test_offline_clock.py`.

**Interfaces:** Consumes `ProtocolJson.parse(byte[],Set<String>,Set<String>,int) -> Map`, `base64(byte[]) -> String`, `unbase64(String,int) -> byte[]`, `Keys.sign(byte[],byte[]) -> byte[64]`, `verify(Map,byte[],byte[]) -> boolean`. Produces `Lease.sign(Map claims,byte[] leasePrivateDer) -> String`, `verify(String compact,Map expected,LeaseTrust trust,long effectiveNow) -> Map`, `claims(Map expected,long issuedAt,boolean renewalEnabled,Long durationSeconds) -> Map`; nullable duration only for disabled policy. `OfflineClock(LongSupplier wall,LongSupplier monotonic)` with `renew(Map freshlyVerifiedLease,boolean authenticatedOnline) -> void`, `effectiveNow() -> long`, `restart() -> void`; time suppliers use seconds. `LeaseTrust(String issuer,Map pinnedJwk,long revision)` with `transition(Map newJwk,long revision,byte[] oldLeaseSignature) -> void`, `lookup(String kid) -> Map`. Python equivalents. Cached-token verification never calls renew.

- [ ] Write `GivenCachedLease_WhenClockRestarts_ThenOnlineRenewalRequired`:

```python
clock.renew(fresh_enabled_lease, authenticated_online=True)
self.assertEqual(clock.effective_now(), 1700000000)
wall.advance(10); monotonic.advance(10)
self.assertEqual(clock.effective_now(), 1700000010)
clock.restart()
with self.assertRaises(ProtocolError): clock.effective_now()
verify(cached_compact, expected, trust, 1700000010)  # does not renew clock
with self.assertRaises(ProtocolError): clock.effective_now()
with self.assertRaises(ProtocolError):
    claims(expected, 9007199254740991, True, 86400)
with self.assertRaises(ProtocolError):
    verify(enabled_without_exp_compact, expected, trust, 1700000010)
with self.assertRaises(ProtocolError):
    verify(disabled_with_exp_compact, expected, trust, 1700000010)
```

Test enabled/disabled policy field matrices, default 86400 and other positive
representable durations without maximum, overflow and `2^53` (Focus 4); original
JWS byte verification including reordered properties; every expected claim;
header alg/type/kid allowlist, none/HS256/token-supplied URLs/keys/crit, duplicates,
unknown fields, invalid compact/base64/signatures; grant sorting/duplicates/scope;
nbf=iat, future, exp exclusive. Test wall and monotonic regression independently,
high-water preservation on re-import, only trusted online renewal restoring use,
disabled policy without fabricated periodic expiry and reconnect requiring fresh
authorization. Test separate lease-key domain, trusted old-key transition, hash/
issuer/revision rollback and unknown key rejection; retain old verification keys
for outstanding/no-expiry leases, with no immediate-revocation claim.

- [ ] Run RED: `tools/protocol-harness/java/mvnw -f tools/protocol-harness/java/pom.xml -Dtest=LeaseTest,OfflineClockTest test`; `PYTHONPATH=tools/protocol-harness/python python -m unittest tests.test_lease tests.test_offline_clock -v`. Expected missing Lease/OfflineClock/LeaseTrust.
- [ ] Implement exact §8 claim/header sets and original signing input. Calculate checked time sums before serialization; anchor uses freshly verified signed `iat`, receipt monotonic time and remembered highest effective time. Separate clock lifecycle from token parsing; disabled-expiry policy does not silently call the enabled-clock path. Keep client and lease trust stores/domain labels separate.
- [ ] Run both commands GREEN and native signature known-answer tests.
- [ ] Stage the Files paths and commit: `git commit -m "feat: validate offline leases and time"`.

