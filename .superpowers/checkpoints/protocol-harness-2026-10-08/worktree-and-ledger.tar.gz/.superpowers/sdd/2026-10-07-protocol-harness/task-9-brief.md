## Task 9: Fail-closed process interface and executed interoperability corpus

**Files:** Create `J/Main.java`, `J/FixtureCases.java`, `P/__main__.py`, `P/fixture_cases.py`, `tools/protocol-harness/verify.py`, `tools/protocol-harness/tests/test_verify.py`, `tools/protocol-harness/fixtures/case-manifest.json`; modify `java/pom.xml`, README. Test `JT/DiagnosticsTest.java`, `PT/test_diagnostics.py`. Generate `docs/security/interoperability-vectors.json` only at the final successful step.

**Interfaces:** Consumes Tasks 1–8 APIs through their listed Interfaces, including the explicitly test-labeled fixed-material wrappers. Both CLIs support `produce <input-file> <output-file>`, `consume <cases-file> <results-file>`, `self-test <results-file>`; arguments designate public fixtures only. `FixtureCases.produce(Map inputs) -> List<Map>`, `consume(List<Map> cases) -> List<Map>`, `selfTest(Map knownAnswers) -> List<Map>` with Python `self_test`. Orchestrator `verify(java_command:list[str],python_command:list[str],output:Path|None,check:Path|None) -> dict` runs complete native suites and both directions; define `HarnessFailure(code:str)` in `verify.py` for orchestrator/benchmark failures, with codes invalid_protocol/unsupported_dependency only, no child exception text. Command `python tools/protocol-harness/verify.py --output PATH` generates; `--check PATH` replays and checks an existing corpus without pretending fresh randomized outputs must match.

- [ ] Write `GivenMissingOrIncompleteProducer_WhenVerified_ThenNoEvidenceWritten`:

```python
for failure in (missing_java, missing_python, empty_tests, skipped_test,
                bad_child_json, wrong_case_ids, stale_digest, failed_consumer):
    with self.assertRaises(HarnessFailure): verify(**failure, output=target, check=None)
    self.assertEqual(target.read_bytes(), previous_valid_bytes)
```

Define each failure with stub subprocess replies in orchestrator tests, not
silently skipping absent Java/Python. Native diagnostics tests force exceptions
containing marker secrets; stdout/stderr contain only stable codes and case IDs,
not marker values, exception text or partial plaintext. Test child timeouts,
nonzero exits, missing/duplicate/extra result IDs, wrong implementation version,
hash mismatch, missing known answers and invalid schema/classification (Focus 5).

- [ ] Run RED: `python3 -m unittest discover -s tools/protocol-harness/tests -p 'test_verify.py' -v`; run Java DiagnosticsTest and Python tests.test_diagnostics with the earlier runner pattern. Expected absent orchestrator/CLI behavior, with discovered tests.
- [ ] Implement bounded file/process handling and independently authored fixture case construction. Each case carries ID, kind, expected context, public inputs/output, producer/version and expected success/rejection. Manifest enumerates all positive families and each mutation from Tasks 1–8; neither side chooses the verifier's expected result. Log only result codes/IDs/digests; public secret outputs go solely to labeled fixture files with explicit fixture-mode commands.
- [ ] Implement real bidirectional verification: Java-produced content/password/recovery/HPKE/proofs/JWS consumed by Python and reverse; compare deterministic encoding/KDF/HKDF/signatures; cross-decrypt actual randomized outputs; verify known answers first. Run each producer's mutations against both consumers and require the exact case-ID manifest, including model/time scenarios independently constructed in each implementation. Native suite reports must be nonempty, no skips, zero failures/errors.
- [ ] Run all native suites and orchestrator unit tests GREEN, then `python tools/protocol-harness/verify.py --output docs/security/interoperability-vectors.json`. Write via temporary file and atomic replacement only after all checks succeed. Include schema version `1`, classification `public-test-fixtures`, actual UTC execution time, implementation versions, source provenance, exact expected bytes/digests and real consumer results; do not fabricate timestamps or attestations.
- [ ] Run `python tools/protocol-harness/verify.py --check docs/security/interoperability-vectors.json`; require both fresh suites and corpus replay to pass, preserving actual randomized producer outputs. Stage exact source/test/manifest/vector paths and commit: `git commit -m "test: prove protocol interoperability"`.

